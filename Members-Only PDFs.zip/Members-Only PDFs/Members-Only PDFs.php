<?php
/**
 * Plugin Name: Members-Only PDFs
 * Description: Protect selected PDFs so only logged-in users (with allowed roles) can view them. Per-file role checkboxes, pretty URLs with original filename, protected URL field, auto .htaccess for uploads/members-only, Repair Routes button, lock icon in Media Library, and configurable redirects (login + forbidden).
 * Version: 1.6.0
 * Author: Jason Cox
 * Author URI: https://github.com/jcjason12108-alt
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) exit;

/** -----------------------------------------------------------------------
 * Constants
 * --------------------------------------------------------------------- */
define('MOP_VERSION',        '1.6.0');
define('MOP_META_PROTECT',   '_mop_members_only');     // "1" / "0"
define('MOP_META_ORIG',      '_mop_orig_filename');    // original filename incl. ext
define('MOP_META_ROLES',     '_mop_allowed_roles');    // array of role slugs per file
define('MOP_DIR',            wp_normalize_path(WP_CONTENT_DIR . '/uploads/members-only'));
define('MOP_URL_PARAM',      'mop_members_file');      // query var for attachment ID
define('MOP_OPTION',         'mop_settings');          // settings array

/** -----------------------------------------------------------------------
 * Activation: ensure dir/.htaccess, defaults, rewrites, flush
 * --------------------------------------------------------------------- */
register_activation_hook(__FILE__, function () {
    if (!file_exists(MOP_DIR)) wp_mkdir_p(MOP_DIR);
    mop_ensure_htaccess();

    $defaults = [
        // Not-logged-in behavior
        'redirect_mode'  => 'login',   // login | page | url
        'redirect_page'  => 0,         // page ID
        'redirect_url'   => '',        // absolute URL
        // Forbidden (logged-in, lacks role) behavior
        'forbidden_mode' => 'none',    // none | page | url
        'forbidden_page' => 0,         // page ID
        'forbidden_url'  => '',        // absolute URL
    ];
    $current = get_option(MOP_OPTION);
    if (!is_array($current)) {
        add_option(MOP_OPTION, $defaults);
    } else {
        update_option(MOP_OPTION, array_merge($defaults, $current));
    }

    mop_register_rewrites();
    flush_rewrite_rules(false);
});

/** -----------------------------------------------------------------------
 * Init: guard folder, add rewrites, one-time safe flush
 * --------------------------------------------------------------------- */
add_action('init', function () {
    if (!file_exists(MOP_DIR)) wp_mkdir_p(MOP_DIR);
    mop_ensure_htaccess();

    mop_register_rewrites();

    if (get_option('mop_flush_rewrite') === '1') {
        flush_rewrite_rules(false);
        delete_option('mop_flush_rewrite');
    }
});

/** Register rewrites + query var */
function mop_register_rewrites(): void {
    add_rewrite_rule('^members-file/([0-9]+)/?$', 'index.php?' . MOP_URL_PARAM . '=$matches[1]', 'top');
    add_rewrite_rule('^members-file/([0-9]+)/(.+)?$', 'index.php?' . MOP_URL_PARAM . '=$matches[1]', 'top');
    add_rewrite_tag('%' . MOP_URL_PARAM . '%', '([0-9]+)');
}
add_filter('query_vars', function ($vars) {
    $vars[] = MOP_URL_PARAM;
    return $vars;
});

/** -----------------------------------------------------------------------
 * Admin notice: only show Nginx hint if not Apache/LiteSpeed
 * --------------------------------------------------------------------- */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;

    if (isset($_GET['mop_repaired']) && $_GET['mop_repaired'] === '1') {
        echo '<div class="notice notice-success is-dismissible"><p>Members-Only PDFs: Routes were flushed.</p></div>';
    }

    $srv = $_SERVER['SERVER_SOFTWARE'] ?? '';
    $is_apache    = stripos($srv, 'Apache')    !== false || function_exists('apache_get_version');
    $is_litespeed = stripos($srv, 'LiteSpeed') !== false;
    if ($is_apache || $is_litespeed) return;

    echo '<div class="notice notice-info"><p><strong>Members-Only PDFs:</strong> If your site uses Nginx, block direct access to <code>wp-content/uploads/members-only/</code> with an Nginx <code>location</code> rule.</p></div>';
});

/** -----------------------------------------------------------------------
 * Settings Page + "Repair Routes" button
 * --------------------------------------------------------------------- */
add_action('admin_menu', function () {
    add_options_page(
        'Members-Only PDFs',
        'Members-Only PDFs',
        'manage_options',
        'mop',
        'mop_render_settings_page'
    );
});

add_action('admin_init', function () {
    register_setting('mop_group', MOP_OPTION, [
        'type' => 'array',
        'sanitize_callback' => 'mop_sanitize_options',
        'default' => [
            'redirect_mode'  => 'login',
            'redirect_page'  => 0,
            'redirect_url'   => '',
            'forbidden_mode' => 'none',
            'forbidden_page' => 0,
            'forbidden_url'  => '',
        ],
    ]);

    add_settings_section('mop_section_login', 'Access Settings — Not Logged In', '__return_false', 'mop');

    add_settings_field('redirect_mode', 'When user is not logged in', function () {
        $o = get_option(MOP_OPTION);
        $mode = $o['redirect_mode'] ?? 'login';
        ?>
        <select name="<?php echo esc_attr(MOP_OPTION); ?>[redirect_mode]" id="mop_redirect_mode">
            <option value="login" <?php selected($mode, 'login'); ?>>Send to WordPress Login</option>
            <option value="page"  <?php selected($mode, 'page');  ?>>Send to Specific Page</option>
            <option value="url"   <?php selected($mode, 'url');   ?>>Send to Custom URL</option>
        </select>
        <?php
    }, 'mop', 'mop_section_login');

    add_settings_field('redirect_page', 'Redirect Page', function () {
        $o = get_option(MOP_OPTION);
        wp_dropdown_pages([
            'name'              => MOP_OPTION . '[redirect_page]',
            'selected'          => intval($o['redirect_page'] ?? 0),
            'show_option_none'  => '-- Select Page --',
            'option_none_value' => 0,
        ]);
        echo '<p class="description">Used only if “Send to Specific Page” is selected.</p>';
    }, 'mop', 'mop_section_login');

    add_settings_field('redirect_url', 'Custom URL', function () {
        $o = get_option(MOP_OPTION);
        $url = esc_url($o['redirect_url'] ?? '');
        echo '<input type="url" class="regular-text" name="' . esc_attr(MOP_OPTION) . '[redirect_url]" value="' . $url . '"/>';
        echo '<p class="description">Absolute URL; used only if “Send to Custom URL” is selected.</p>';
    }, 'mop', 'mop_section_login');

    // Forbidden (logged-in, lacks role)
    add_settings_section('mop_section_forbidden', 'Access Settings — Lacks Permission (Logged In)', '__return_false', 'mop');

    add_settings_field('forbidden_mode', 'When user lacks permission', function () {
        $o = get_option(MOP_OPTION);
        $mode = $o['forbidden_mode'] ?? 'none';
        ?>
        <select name="<?php echo esc_attr(MOP_OPTION); ?>[forbidden_mode]" id="mop_forbidden_mode">
            <option value="none" <?php selected($mode, 'none'); ?>>Do nothing (send 403)</option>
            <option value="page" <?php selected($mode, 'page'); ?>>Send to Specific Page</option>
            <option value="url"  <?php selected($mode, 'url');  ?>>Send to Custom URL</option>
        </select>
        <?php
    }, 'mop', 'mop_section_forbidden');

    add_settings_field('forbidden_page', 'Forbidden Redirect Page', function () {
        $o = get_option(MOP_OPTION);
        wp_dropdown_pages([
            'name'              => MOP_OPTION . '[forbidden_page]',
            'selected'          => intval($o['forbidden_page'] ?? 0),
            'show_option_none'  => '-- Select Page --',
            'option_none_value' => 0,
        ]);
        echo '<p class="description">Used only if “Send to Specific Page” is selected above.</p>';
    }, 'mop', 'mop_section_forbidden');

    add_settings_field('forbidden_url', 'Forbidden Custom URL', function () {
        $o = get_option(MOP_OPTION);
        $url = esc_url($o['forbidden_url'] ?? '');
        echo '<input type="url" class="regular-text" name="' . esc_attr(MOP_OPTION) . '[forbidden_url]" value="' . $url . '"/>';
        echo '<p class="description">Absolute URL; used only if “Send to Custom URL” is selected above.</p>';
    }, 'mop', 'mop_section_forbidden');
});

function mop_render_settings_page() {
    if (current_user_can('manage_options') && isset($_POST['mop_repair_routes'])) {
        check_admin_referer('mop_repair_routes');
        mop_register_rewrites();
        flush_rewrite_rules(false);
        wp_safe_redirect(add_query_arg('mop_repaired', '1', menu_page_url('mop', false)));
        exit;
    }
    ?>
    <div class="wrap">
        <h1>Members-Only PDFs</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('mop_group');
            do_settings_sections('mop');
            submit_button('Save Changes');
            ?>
        </form>
        <hr />
        <h2>Maintenance</h2>
        <form method="post">
            <?php wp_nonce_field('mop_repair_routes'); ?>
            <p>If protected links 404 after a migration or plugin/theme changes, click to rebuild rewrite rules.</p>
            <p><button type="submit" name="mop_repair_routes" class="button button-secondary">Repair Routes (Flush Permalinks)</button></p>
        </form>
    </div>
    <?php
}

function mop_sanitize_options($in) {
    return [
        'redirect_mode'  => in_array(($in['redirect_mode'] ?? 'login'), ['login','page','url'], true) ? $in['redirect_mode'] : 'login',
        'redirect_page'  => max(0, intval($in['redirect_page'] ?? 0)),
        'redirect_url'   => esc_url_raw($in['redirect_url'] ?? ''),
        'forbidden_mode' => in_array(($in['forbidden_mode'] ?? 'none'), ['none','page','url'], true) ? $in['forbidden_mode'] : 'none',
        'forbidden_page' => max(0, intval($in['forbidden_page'] ?? 0)),
        'forbidden_url'  => esc_url_raw($in['forbidden_url'] ?? ''),
    ];
}

/** -----------------------------------------------------------------------
 * Media UI: members-only toggle, Protected URL, per-file roles (checkboxes)
 * --------------------------------------------------------------------- */
add_filter('attachment_fields_to_edit', function ($form_fields, $post) {
    if (get_post_mime_type($post) !== 'application/pdf') return $form_fields;

    $id = (int)$post->ID;
    $is_protected  = (get_post_meta($id, MOP_META_PROTECT, true) === '1');
    $all_roles     = mop_get_all_roles();            // [slug => label]
    $allowed_roles = mop_get_allowed_roles($id);     // array of slugs
    $csv_value     = implode(',', $allowed_roles);

    // Toggle
    $form_fields['mop_members_only'] = [
        'label' => __('Members-Only', 'mop'),
        'input' => 'html',
        'html'  => '<label><input type="checkbox" name="attachments[' . esc_attr($id) . '][mop_members_only]" value="1" ' . checked(true, $is_protected, false) . '> ' . esc_html__('Only logged-in users can view', 'mop') . '</label>',
        'helps' => __('Moves the PDF into a protected folder and serves via a secure endpoint.', 'mop'),
    ];

    // Protected URL (copy-ready)
    if ($is_protected) {
        $protected_url = mop_build_protected_url($id);
        $form_fields['mop_members_only_url'] = [
            'label' => __('Protected URL', 'mop'),
            'input' => 'html',
            'html'  => '<input type="text" class="regular-text code" readonly value="' . esc_attr($protected_url) . '" onclick="this.select();" />' .
                       '<p class="description">Share this URL with members. It includes the original filename.</p>',
        ];
    }

    // Per-file Allowed Roles (checkboxes) + hidden CSV synchronized by JS
    $html = '<input type="hidden" class="mop-roles-csv" name="attachments[' . esc_attr($id) . '][mop_allowed_roles_csv]" value="' . esc_attr($csv_value) . '">';
    foreach ($all_roles as $slug => $name) {
        $checked = in_array($slug, $allowed_roles, true) ? 'checked' : '';
        $html .= '<label style="display:block;margin:.15em 0;">'
              .  '<input type="checkbox" class="mop-role" data-role="' . esc_attr($slug) . '" ' . $checked . '> '
              .  esc_html($name)
              .  '</label>';
    }
    $warn = ($is_protected && empty($allowed_roles))
        ? '<p style="color:#b32d2e;margin-top:.25em;"><strong>' . esc_html__('No roles selected: protected file will be inaccessible to non-admins.', 'mop') . '</strong></p>'
        : '';

    $form_fields['mop_allowed_roles'] = [
        'label' => __('Roles that can view (this file)', 'mop'),
        'input' => 'html',
        'html'  => $html . $warn . '<p class="description">Tick multiple roles; users with <em>any</em> selected role can view.</p>',
        'helps' => __('Leave all unchecked to deny everyone except administrators.', 'mop'),
    ];

    return $form_fields;
}, 10, 2);

/**
 * Admin JS: keep hidden CSV in sync with the role checkboxes
 */
add_action('admin_enqueue_scripts', function ($hook) {
    if (!in_array($hook, ['upload.php','media.php','post.php','post-new.php','site-editor.php','widgets.php','customize.php'], true)) return;

    $js = <<<JS
(function($){
  function syncCSV(container){
    var boxes = container.querySelectorAll('input.mop-role[type="checkbox"]');
    var vals = [];
    boxes.forEach(function(b){ if(b.checked){ vals.push(b.getAttribute('data-role')); }});
    var hidden = container.querySelector('input.mop-roles-csv');
    if (hidden) hidden.value = vals.join(',');
  }
  function wire(container){
    if (!container) return;
    container.addEventListener('change', function(e){
      if (e.target && e.target.matches('input.mop-role[type="checkbox"]')){
        syncCSV(container);
      }
    });
    syncCSV(container);
  }
  document.querySelectorAll('.compat-attachment-fields').forEach(wire);
  var mo = new MutationObserver(function(muts){
    muts.forEach(function(m){
      m.addedNodes && m.addedNodes.forEach(function(n){
        if (n.nodeType !== 1) return;
        if (n.matches('.attachment-details, .edit-attachment-frame, .media-modal-content, .compat-attachment-fields')){
          n.querySelectorAll('.compat-attachment-fields').forEach(wire);
        }
      });
    });
  });
  mo.observe(document.body, {childList:true, subtree:true});
})(jQuery);
JS;
    wp_add_inline_script('media-views', $js, 'after');
});

/** Persist: protect toggle + roles CSV */
add_filter('attachment_fields_to_save', function ($post, $attachment) {
    $id = (int)$post['ID'];

    // Protect toggle
    $want_protected = isset($attachment['mop_members_only']) ? '1' : '0';
    $curr           = get_post_meta($id, MOP_META_PROTECT, true) === '1' ? '1' : '0';

    if ($want_protected !== $curr) {
        update_post_meta($id, MOP_META_PROTECT, $want_protected);
        // Capture original filename on first protect
        if ($want_protected === '1' && !get_post_meta($id, MOP_META_ORIG, true)) {
            $path = get_attached_file($id, true);
            if ($path) update_post_meta($id, MOP_META_ORIG, wp_basename($path));
        }
        mop_move_file_protection_state($id, $want_protected === '1');
    }

    // Allowed roles from CSV (authoritative)
    $roles = [];
    if (!empty($attachment['mop_allowed_roles_csv'])) {
        $parts = array_filter(array_map('sanitize_text_field', explode(',', $attachment['mop_allowed_roles_csv'])));
        $roles = array_values(array_unique($parts));
    }
    // keep only valid roles actually registered on the site
    $valid = array_keys(mop_get_all_roles());
    $roles = array_values(array_intersect($roles, $valid));
    update_post_meta($id, MOP_META_ROLES, $roles);

    return $post;
}, 10, 2);

/** -----------------------------------------------------------------------
 * URL rewriting for protected PDFs → /members-file/{id}/{orig-filename}
 * --------------------------------------------------------------------- */
add_filter('wp_get_attachment_url', function ($url, $post_id) {
    if (!mop_is_pdf($post_id)) return $url;
    if (get_post_meta($post_id, MOP_META_PROTECT, true) !== '1') return $url;
    return mop_build_protected_url($post_id);
}, 10, 2);

function mop_build_protected_url(int $post_id): string {
    $fname = get_post_meta($post_id, MOP_META_ORIG, true);
    if (!$fname) {
        $p = get_attached_file($post_id, true);
        $fname = $p ? wp_basename($p) : ('file-' . $post_id . '.pdf');
    }
    return home_url('/members-file/' . $post_id . '/' . rawurlencode($fname));
}

/** -----------------------------------------------------------------------
 * Route: serve protected PDFs (requires login + role match)
 * --------------------------------------------------------------------- */
add_action('template_redirect', function () {
    $id = get_query_var(MOP_URL_PARAM);
    if (!$id) return;

    $attachment_id = absint($id);
    if (!$attachment_id || !mop_is_pdf($attachment_id)) {
        mop_404();
    }

    // Must be protected to use this endpoint
    if (get_post_meta($attachment_id, MOP_META_PROTECT, true) !== '1') {
        mop_404();
    }

    // Not logged in → redirect per settings
    if (!is_user_logged_in()) {
        $o = get_option(MOP_OPTION);
        $mode = $o['redirect_mode'] ?? 'login';
        switch ($mode) {
            case 'page':
                $pid = intval($o['redirect_page'] ?? 0);
                if ($pid > 0 && ($target = get_permalink($pid))) { wp_safe_redirect($target); exit; }
                auth_redirect(); exit;
            case 'url':
                $url = $o['redirect_url'] ?? '';
                if (!empty($url)) { wp_safe_redirect($url); exit; }
                auth_redirect(); exit;
            case 'login':
            default:
                auth_redirect(); exit;
        }
    }

    // Logged in → must have one of the allowed roles (admins bypass)
    if (!mop_user_can_view($attachment_id)) {
        $o = get_option(MOP_OPTION);
        $mode = $o['forbidden_mode'] ?? 'none';
        if ($mode === 'page') {
            $pid = intval($o['forbidden_page'] ?? 0);
            if ($pid > 0 && ($target = get_permalink($pid))) { wp_safe_redirect($target); exit; }
        } elseif ($mode === 'url') {
            $url = $o['forbidden_url'] ?? '';
            if (!empty($url)) { wp_safe_redirect($url); exit; }
        }
        // Default: 403
        status_header(403);
        nocache_headers();
        exit('Forbidden');
    }

    // Ensure file exists and is in protected dir; if not, try to move now
    $file = get_attached_file($attachment_id, true);
    if (!$file || !file_exists($file) || strpos(wp_normalize_path($file), MOP_DIR) !== 0) {
        mop_move_file_protection_state($attachment_id, true);
        $file = get_attached_file($attachment_id, true);
        if (!$file || !file_exists($file) || strpos(wp_normalize_path($file), MOP_DIR) !== 0) {
            mop_404();
        }
    }

    $orig = get_post_meta($attachment_id, MOP_META_ORIG, true);
    if (!$orig) $orig = wp_basename($file);

    mop_stream_pdf($file, $orig);
    exit;
});

/** -----------------------------------------------------------------------
 * Media Grid & Modal Lock Icon (robust)
 * --------------------------------------------------------------------- */

/** Expose protection flag to Media Library JS models (PDFs only) */
add_filter('wp_prepare_attachment_for_js', function ($response, $attachment, $meta) {
    if (get_post_mime_type($attachment) === 'application/pdf') {
        $response['mopProtected'] = (get_post_meta($attachment->ID, MOP_META_PROTECT, true) === '1');
    }
    return $response;
}, 10, 3);

/** Enqueue minimal CSS and resilient JS for lock overlay */
add_action('admin_enqueue_scripts', function ($hook) {
    $allowed_hooks = ['upload.php','media.php','post.php','post-new.php','site-editor.php','widgets.php','customize.php'];
    if (!in_array($hook, $allowed_hooks, true)) return;

    wp_enqueue_style('dashicons');

    $css = <<<CSS
.attachments .attachment { position: relative; }
.mop-lock {
  position: absolute;
  top: 6px; right: 6px;
  z-index: 1000;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px; height: 22px;
  border-radius: 50%;
  background: rgba(0,0,0,.55);
  color: #fff;
}
.mop-lock .dashicons { width: 16px; height: 16px; font-size: 16px; line-height: 1; }
CSS;
    wp_add_inline_style('dashicons', $css);

    $js = <<<JS
(function(){
  function ready(fn){ if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function isPdfModel(m){
    if (!m) return false;
    var subtype = String(m.get('subtype')||'').toLowerCase();
    var fname   = String(m.get('filename')||'');
    return (subtype === 'pdf') || (/\\.pdf$/i.test(fname));
  }
  function isProtectedModel(m){
    return !!(m && m.get && (m.get('mopProtected') || m.get('ll706Protected') || m.get('mop_protected')));
  }
  function getAttachmentModelByEl(tile){
    var id = tile && tile.getAttribute && tile.getAttribute('data-id');
    if (!id || !window.wp || !wp.media || !wp.media.attachment) return null;
    try { return wp.media.attachment(parseInt(id,10)); } catch(e){ return null; }
  }
  function paintTile(tile){
    if (!tile) return;
    var old = tile.querySelector('.mop-lock'); if (old) old.remove();
    var model = getAttachmentModelByEl(tile);
    if (!model) return;
    if (typeof model.get !== 'function' || !model.get('filename')) {
      if (model.once) model.once('change', function(){ paintTile(tile); });
      if (model.fetch && model.fetch().always) model.fetch().always(function(){ paintTile(tile); });
      return;
    }
    var show = isPdfModel(model) && isProtectedModel(model);
    if (show){
      var span = document.createElement('span');
      span.className = 'mop-lock';
      span.title = 'Protected';
      span.innerHTML = '<span class="dashicons dashicons-lock"></span>';
      tile.appendChild(span);
    }
  }
  function paintAll(root){
    if (!root) root = document;
    var tiles = root.querySelectorAll('.attachments .attachment');
    (tiles.forEach ? tiles : Array.prototype.slice.call(tiles)).forEach(paintTile);
  }
  function attachObserver(){
    var root = document.body;
    if (!root) return;
    var mo = new MutationObserver(function(muts){
      muts.forEach(function(m){
        if (m.type === 'childList'){
          (m.addedNodes || []).forEach(function(n){
            if (!n.querySelectorAll) return;
            var tiles = (n.matches && n.matches('.attachments .attachment')) ? [n] : n.querySelectorAll('.attachments .attachment');
            (tiles.forEach ? tiles : Array.prototype.slice.call(tiles)).forEach(paintTile);
          });
        }
      });
    });
    mo.observe(root, {childList:true, subtree:true});
  }
  ready(function(){ paintAll(document); attachObserver(); });
})();
JS;
    wp_add_inline_script('media-views', $js, 'after');
});

/** -----------------------------------------------------------------------
 * Helpers
 * --------------------------------------------------------------------- */
function mop_get_all_roles(): array {
    $roles = [];
    foreach (wp_roles()->roles as $slug => $role) {
        $roles[$slug] = $role['name'];
    }
    return $roles;
}

function mop_get_allowed_roles(int $post_id): array {
    $val = get_post_meta($post_id, MOP_META_ROLES, true);
    return is_array($val) ? $val : [];
}

function mop_user_can_view(int $post_id): bool {
    if (current_user_can('manage_options')) return true; // admins bypass
    $allowed = mop_get_allowed_roles($post_id);
    if (empty($allowed)) return false;
    $user = wp_get_current_user();
    if (!$user || empty($user->roles)) return false;
    return (bool) array_intersect($user->roles, $allowed); // OR logic across selected roles
}

function mop_is_pdf(int $post_id): bool {
    $mime = (string) get_post_mime_type($post_id);
    if ($mime && stripos($mime, 'pdf') !== false) return true;
    $p = get_attached_file($post_id, true);
    return $p && preg_match('/\.pdf$/i', $p);
}

function mop_ensure_htaccess(): void {
    if (!file_exists(MOP_DIR)) return;
    $ht = MOP_DIR . '/.htaccess';
    if (!file_exists($ht)) {
        $rules = <<<HTACC
# Members-Only PDFs
Options -Indexes

# Apache 2.4+ / LiteSpeed
<IfModule mod_authz_core.c>
  Require all denied
</IfModule>

# Apache 2.2 fallback
<IfModule !mod_authz_core.c>
  Deny from all
</IfModule>
HTACC;
        @file_put_contents($ht, $rules);
    }
}

function mop_move_file_protection_state(int $attachment_id, bool $protect): void {
    $file = get_attached_file($attachment_id, true);
    if (!$file || !file_exists($file)) return;
    if (!mop_is_pdf($attachment_id)) return;

    $uploads      = wp_get_upload_dir();
    $uploads_base = wp_normalize_path($uploads['basedir']);
    $basename     = wp_basename($file);
    $protected    = wp_normalize_path(trailingslashit(MOP_DIR) . $basename);

    if ($protect) {
        if (!get_post_meta($attachment_id, MOP_META_ORIG, true)) {
            update_post_meta($attachment_id, MOP_META_ORIG, $basename);
        }
        if (strpos(wp_normalize_path($file), MOP_DIR) === false) {
            $protected = mop_unique_path($protected);
            if (@rename($file, $protected)) {
                update_attached_file($attachment_id, $protected);
            }
        }
    } else {
        $subdir     = date('/Y/m/', (int) (filemtime($file) ?: time()));
        $target_dir = wp_normalize_path($uploads_base . $subdir);
        if (!file_exists($target_dir)) wp_mkdir_p($target_dir);
        $target_path = mop_unique_path(wp_normalize_path($target_dir . wp_basename($file)));
        if (@rename($file, $target_path)) {
            update_attached_file($attachment_id, $target_path);
        }
    }
}

function mop_unique_path(string $path): string {
    $dir = wp_normalize_path(trailingslashit(dirname($path)));
    $base = pathinfo($path, PATHINFO_FILENAME);
    $ext  = pathinfo($path, PATHINFO_EXTENSION);
    $i = 0;
    $candidate = $path;
    while (file_exists($candidate)) {
        $i++;
        $candidate = $dir . $base . '-' . $i . '.' . $ext;
    }
    return $candidate;
}

function mop_stream_pdf(string $filepath, string $display_name): void {
    nocache_headers();
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . mop_suggest_filename($display_name) . '"');
    header('Content-Length: ' . filesize($filepath));
    header('Accept-Ranges: none');

    $last_modified = gmdate('D, d M Y H:i:s', filemtime($filepath)) . ' GMT';
    $etag = '"' . md5($last_modified . '|' . basename($filepath)) . '"';
    header('Last-Modified: ' . $last_modified);
    header('ETag: ' . $etag);

    if (
        (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim($_SERVER['HTTP_IF_NONE_MATCH']) === $etag) ||
        (isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) && trim($_SERVER['HTTP_IF_MODIFIED_SINCE']) === $last_modified)
    ) {
        status_header(304);
        exit;
    }

    status_header(200);
    readfile($filepath);
}

function mop_suggest_filename(string $name): string {
    $n = trim($name);
    if ($n === '') $n = 'file.pdf';
    if (strtolower(substr($n, -4)) !== '.pdf') $n .= '.pdf';
    $n = str_replace(["\r","\n","\""], ['','',''], $n);
    return $n;
}

function mop_404(): void {
    status_header(404);
    nocache_headers();
    exit('Not Found');
}