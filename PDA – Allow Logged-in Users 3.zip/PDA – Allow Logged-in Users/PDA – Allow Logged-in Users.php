<?php
/**
 * Plugin Name: LL706 Members-Only PDFs
 * Description: Protect selected PDFs so only logged-in users can view them. Includes admin redirect settings, pretty URLs with original filename, auto-flush, Repair Routes button, Protected URL display on attachment edit, and a reliable lock icon on Media grid for protected PDFs.
 * Version: 1.3.1
 * Author: IAM LL706
 */

if (!defined('ABSPATH')) exit;

/** -----------------------------------------------------------------------
 * Constants
 * --------------------------------------------------------------------- */
define('LL706_MOP_VERSION', '1.3.1');
define('LL706_MOP_META_KEY',   '_ll706_members_only');     // "1" / "0"
define('LL706_MOP_META_ORIG',  '_ll706_orig_filename');    // original filename incl. ext
define('LL706_MOP_DIR',        wp_normalize_path(WP_CONTENT_DIR . '/uploads/members-only'));
define('LL706_MOP_URL_PARAM',  'll706_members_file');      // query var for attachment ID
define('LL706_MOP_OPTION',     'll706_mop_settings');      // ['redirect_mode','redirect_page','redirect_url']

/** -----------------------------------------------------------------------
 * Activation: ensure dir/.htaccess, set defaults, register & FLUSH rewrites
 * --------------------------------------------------------------------- */
register_activation_hook(__FILE__, function () {
    if (!file_exists(LL706_MOP_DIR)) wp_mkdir_p(LL706_MOP_DIR);
    ll706_mop_ensure_htaccess();

    if (!get_option(LL706_MOP_OPTION)) {
        add_option(LL706_MOP_OPTION, [
            'redirect_mode' => 'login',   // login | page | url
            'redirect_page' => 0,         // page ID
            'redirect_url'  => '',        // absolute URL
        ]);
    }

    ll706_mop_register_rewrites();
    flush_rewrite_rules(false); // auto-flush on activation
});

/** -----------------------------------------------------------------------
 * Init: keep .htaccess present, register rewrites, one-time safe flush
 * --------------------------------------------------------------------- */
add_action('init', function () {
    if (!file_exists(LL706_MOP_DIR)) wp_mkdir_p(LL706_MOP_DIR);
    ll706_mop_ensure_htaccess();

    ll706_mop_register_rewrites();

    if (get_option('ll706_mop_flush_rewrite') === '1') {
        flush_rewrite_rules(false);
        delete_option('ll706_mop_flush_rewrite');
    }
});

/** Register rewrites + query var */
function ll706_mop_register_rewrites(): void {
    // Accept /members-file/{id} and /members-file/{id}/{filename}
    add_rewrite_rule('^members-file/([0-9]+)/?$', 'index.php?' . LL706_MOP_URL_PARAM . '=$matches[1]', 'top');
    add_rewrite_rule('^members-file/([0-9]+)/(.+)?$', 'index.php?' . LL706_MOP_URL_PARAM . '=$matches[1]', 'top');
    add_rewrite_tag('%' . LL706_MOP_URL_PARAM . '%', '([0-9]+)');
}
add_filter('query_vars', function ($vars) {
    $vars[] = LL706_MOP_URL_PARAM;
    return $vars;
});

/** -----------------------------------------------------------------------
 * Admin notice: only show Nginx hint if not Apache/LiteSpeed
 * --------------------------------------------------------------------- */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;

    if (isset($_GET['ll706_mop_repaired']) && $_GET['ll706_mop_repaired'] === '1') {
        echo '<div class="notice notice-success is-dismissible"><p>Members-Only PDFs: Routes were flushed.</p></div>';
    }

    $srv = $_SERVER['SERVER_SOFTWARE'] ?? '';
    $is_apache    = stripos($srv, 'Apache')    !== false || function_exists('apache_get_version');
    $is_litespeed = stripos($srv, 'LiteSpeed') !== false;
    if ($is_apache || $is_litespeed) return; // .htaccess honored → no notice

    echo '<div class="notice notice-info"><p><strong>LL706 Members-Only PDFs:</strong> If you are using Nginx, block direct access to <code>wp-content/uploads/members-only/</code> with an Nginx location rule.</p></div>';
});

/** -----------------------------------------------------------------------
 * Settings Page (Settings → Members-Only PDFs) + "Repair Routes" button
 * --------------------------------------------------------------------- */
add_action('admin_menu', function () {
    add_options_page(
        'Members-Only PDFs',
        'Members-Only PDFs',
        'manage_options',
        'll706-mop',
        'll706_mop_render_settings_page'
    );
});

add_action('admin_init', function () {
    register_setting('ll706_mop_group', LL706_MOP_OPTION, [
        'type' => 'array',
        'sanitize_callback' => 'll706_mop_sanitize_options',
        'default' => [
            'redirect_mode' => 'login',
            'redirect_page' => 0,
            'redirect_url'  => '',
        ],
    ]);
    add_settings_section('ll706_mop_section', 'Access Settings', '__return_false', 'll706_mop');

    add_settings_field('redirect_mode', 'When user is not logged in', function () {
        $o = get_option(LL706_MOP_OPTION);
        $mode = $o['redirect_mode'] ?? 'login';
        ?>
        <select name="<?php echo esc_attr(LL706_MOP_OPTION); ?>[redirect_mode]" id="ll706_mop_redirect_mode">
            <option value="login" <?php selected($mode, 'login'); ?>>Send to WordPress Login</option>
            <option value="page"  <?php selected($mode, 'page');  ?>>Send to Specific Page</option>
            <option value="url"   <?php selected($mode, 'url');   ?>>Send to Custom URL</option>
        </select>
        <?php
    }, 'll706_mop', 'll706_mop_section');

    add_settings_field('redirect_page', 'Redirect Page', function () {
        $o = get_option(LL706_MOP_OPTION);
        wp_dropdown_pages([
            'name'              => LL706_MOP_OPTION . '[redirect_page]',
            'selected'          => intval($o['redirect_page'] ?? 0),
            'show_option_none'  => '-- Select Page --',
            'option_none_value' => 0,
        ]);
        echo '<p class="description">Used only if "Send to Specific Page" is selected.</p>';
    }, 'll706_mop', 'll706_mop_section');

    add_settings_field('redirect_url', 'Custom URL', function () {
        $o = get_option(LL706_MOP_OPTION);
        $url = esc_url($o['redirect_url'] ?? '');
        echo '<input type="url" class="regular-text" name="' . esc_attr(LL706_MOP_OPTION) . '[redirect_url]" value="' . $url . '"/>';
        echo '<p class="description">Absolute URL, used only if "Send to Custom URL" is selected.</p>';
    }, 'll706_mop', 'll706_mop_section');
});

/** Settings page renderer + Repair Routes handler */
function ll706_mop_render_settings_page() {
    if (current_user_can('manage_options') && isset($_POST['ll706_mop_repair_routes'])) {
        check_admin_referer('ll706_mop_repair_routes');
        ll706_mop_register_rewrites();
        flush_rewrite_rules(false);
        wp_safe_redirect(add_query_arg('ll706_mop_repaired', '1', menu_page_url('ll706-mop', false)));
        exit;
    }
    ?>
    <div class="wrap">
        <h1>Members-Only PDFs</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ll706_mop_group');
            do_settings_sections('ll706_mop');
            submit_button('Save Changes');
            ?>
        </form>
        <hr />
        <h2>Maintenance</h2>
        <form method="post">
            <?php wp_nonce_field('ll706_mop_repair_routes'); ?>
            <p>If protected links 404 after a migration or plugin/theme changes, click to rebuild rewrite rules.</p>
            <p><button type="submit" name="ll706_mop_repair_routes" class="button button-secondary">Repair Routes (Flush Permalinks)</button></p>
        </form>
    </div>
    <?php
}

function ll706_mop_sanitize_options($in) {
    return [
        'redirect_mode' => in_array(($in['redirect_mode'] ?? 'login'), ['login','page','url'], true) ? $in['redirect_mode'] : 'login',
        'redirect_page' => max(0, intval($in['redirect_page'] ?? 0)),
        'redirect_url'  => esc_url_raw($in['redirect_url'] ?? ''),
    ];
}

/** -----------------------------------------------------------------------
 * Media UI: add checkbox, show Protected URL when enabled
 * --------------------------------------------------------------------- */
add_filter('attachment_fields_to_edit', function ($form_fields, $post) {
    if (get_post_mime_type($post) !== 'application/pdf') return $form_fields;

    // Toggle
    $val = get_post_meta($post->ID, LL706_MOP_META_KEY, true) === '1' ? '1' : '0';
    $form_fields['ll706_members_only'] = [
        'label' => __('Members-Only', 'll706-mop'),
        'input' => 'html',
        'html'  => '<label><input type="checkbox" name="attachments[' . esc_attr($post->ID) . '][ll706_members_only]" value="1" ' . checked('1', $val, false) . '> ' . esc_html__('Only logged-in users can view', 'll706-mop') . '</label>',
        'helps' => __('Moves the PDF into a protected folder and serves via a secure endpoint.', 'll706-mop'),
    ];

    // Protected URL (copy-ready)
    if ($val === '1') {
        $protected_url = ll706_mop_build_protected_url($post->ID);
        $form_fields['ll706_members_only_url'] = [
            'label' => __('Protected URL', 'll706-mop'),
            'input' => 'html',
            'html'  => '<input type="text" class="regular-text code" readonly value="' . esc_attr($protected_url) . '" onclick="this.select();" />' .
                       '<p class="description">Share this URL with members. It includes the original filename.</p>',
        ];
    }

    return $form_fields;
}, 10, 2);

add_filter('attachment_fields_to_save', function ($post, $attachment) {
    $want_protected = isset($attachment['ll706_members_only']) ? '1' : '0';
    $curr           = get_post_meta($post['ID'], LL706_MOP_META_KEY, true) === '1' ? '1' : '0';

    if ($want_protected !== $curr) {
        update_post_meta($post['ID'], LL706_MOP_META_KEY, $want_protected);
        // Capture original filename on first protect
        if ($want_protected === '1' && !get_post_meta($post['ID'], LL706_MOP_META_ORIG, true)) {
            $path = get_attached_file($post['ID'], true);
            if ($path) update_post_meta($post['ID'], LL706_MOP_META_ORIG, wp_basename($path));
        }
        ll706_mop_move_file_protection_state((int)$post['ID'], $want_protected === '1');
    }
    return $post;
}, 10, 2);

/** -----------------------------------------------------------------------
 * URL rewriting for protected PDFs → /members-file/{id}/{orig-filename}
 * --------------------------------------------------------------------- */
add_filter('wp_get_attachment_url', function ($url, $post_id) {
    if (!ll706_mop_is_pdf($post_id)) return $url;
    if (get_post_meta($post_id, LL706_MOP_META_KEY, true) !== '1') return $url;
    return ll706_mop_build_protected_url($post_id);
}, 10, 2);

function ll706_mop_build_protected_url(int $post_id): string {
    $fname = get_post_meta($post_id, LL706_MOP_META_ORIG, true);
    if (!$fname) {
        $p = get_attached_file($post_id, true);
        $fname = $p ? wp_basename($p) : ('file-' . $post_id . '.pdf');
    }
    return home_url('/members-file/' . $post_id . '/' . rawurlencode($fname));
}

/** -----------------------------------------------------------------------
 * Route: serve protected PDFs (requires login or custom redirect)
 * --------------------------------------------------------------------- */
add_action('template_redirect', function () {
    $id = get_query_var(LL706_MOP_URL_PARAM);
    if (!$id) return;

    $attachment_id = absint($id);
    if (!$attachment_id || !ll706_mop_is_pdf($attachment_id)) {
        ll706_mop_404();
    }

    // Gate: user must be logged in; else redirect per settings
    if (!is_user_logged_in()) {
        $o = get_option(LL706_MOP_OPTION);
        $mode = $o['redirect_mode'] ?? 'login';
        switch ($mode) {
            case 'page':
                $pid = intval($o['redirect_page'] ?? 0);
                if ($pid > 0 && ($target = get_permalink($pid))) { wp_safe_redirect($target); exit; }
                auth_redirect(); exit;
            case 'url':
                $url = $o['redirect_url'] ?? '';
                if (!empty($url)) { wp_safe_redirect($url); exit; }
                auth_redirect(); exit;
            case 'login':
            default:
                auth_redirect(); exit;
        }
    }

    if (get_post_meta($attachment_id, LL706_MOP_META_KEY, true) !== '1') ll706_mop_404();

    // Ensure file exists and is in protected dir; if not, try to move now
    $file = get_attached_file($attachment_id, true);
    if (!$file || !file_exists($file) || strpos(wp_normalize_path($file), LL706_MOP_DIR) !== 0) {
        ll706_mop_move_file_protection_state($attachment_id, true);
        $file = get_attached_file($attachment_id, true);
        if (!$file || !file_exists($file) || strpos(wp_normalize_path($file), LL706_MOP_DIR) !== 0) {
            ll706_mop_404();
        }
    }

    $orig = get_post_meta($attachment_id, LL706_MOP_META_ORIG, true);
    if (!$orig) $orig = wp_basename($file);

    ll706_mop_stream_pdf($file, $orig);
    exit;
});

/** -----------------------------------------------------------------------
 * Media Grid Lock Icon (reliable: MutationObserver approach)
 * --------------------------------------------------------------------- */

/**
 * Expose protection flag to Media Library JS models.
 */
add_filter('wp_prepare_attachment_for_js', function ($response, $attachment, $meta) {
    if (get_post_mime_type($attachment) === 'application/pdf') {
        $response['ll706Protected'] = (get_post_meta($attachment->ID, LL706_MOP_META_KEY, true) === '1');
    }
    return $response;
}, 10, 3);

/**
 * Media grid: overlay a small lock on protected PDFs (grid view).
 */
add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'upload.php') return; // Media Library main screen

    wp_enqueue_style('dashicons');

    // Minimal CSS for the lock bubble
    $css = <<<CSS
.attachments .attachment { position: relative; }
.ll706-lock {
  position: absolute;
  top: 6px; right: 6px;
  z-index: 1000;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px; height: 22px;
  border-radius: 50%;
  background: rgba(0,0,0,.55);
  color: #fff;
}
.ll706-lock .dashicons { width: 16px; height: 16px; font-size: 16px; line-height: 1; }
CSS;
    wp_add_inline_style('dashicons', $css);

    // Robust JS using MutationObserver
    $js = <<<JS
(function($){
  function ready(fn){ if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  ready(function(){
    if (!window.wp || !wp.media) return;

    function getModelForTile(el){
      var id = el && el.getAttribute && el.getAttribute('data-id');
      if (!id) return null;
      try {
        var frame = wp.media.frame || (wp.media.frames && wp.media.frames.browse);
        var state = frame && frame.state && frame.state();
        var lib   = state && state.get && state.get('library');
        var model = lib && lib.get && lib.get(parseInt(id,10));
        return model || null;
      } catch(e){ return null; }
    }

    function paintTile(el){
      if (!el) return;
      var old = el.querySelector('.ll706-lock'); if (old) old.remove();
      var model = getModelForTile(el);
      if (!model) return;

      var subtype = String(model.get('subtype')||'').toLowerCase();
      var fname   = String(model.get('filename')||'');
      var isPdf   = (subtype === 'pdf') || (/\\.pdf$/i.test(fname));
      var isProt  = !!model.get('ll706Protected');

      if (isPdf && isProt){
        var span = document.createElement('span');
        span.className = 'll706-lock';
        span.title = 'Protected';
        span.innerHTML = '<span class="dashicons dashicons-lock"></span>';
        el.appendChild(span);
      }
    }

    function paintAll(){
      document.querySelectorAll('.attachments .attachment').forEach(paintTile);
    }

    var container = document.querySelector('.attachments');
    function attachObserver(root){
      if (!root) return;
      paintAll();
      var mo = new MutationObserver(function(muts){
        muts.forEach(function(m){
          if (m.type === 'childList'){
            m.addedNodes && m.addedNodes.forEach(function(n){
              if (n.nodeType !== 1) return;
              if (n.classList.contains('attachment')) paintTile(n);
              var list = n.querySelectorAll ? n.querySelectorAll('.attachment') : [];
              list.forEach(paintTile);
            });
          }
        });
      });
      mo.observe(root, {childList:true, subtree:true});
    }

    if (!container){
      var tries = 0, t = setInterval(function(){
        container = document.querySelector('.attachments');
        if (container || ++tries > 40){
          clearInterval(t);
          attachObserver(container);
        }
      }, 100);
    } else {
      attachObserver(container);
    }

    if (wp.media && wp.media.frame){
      try {
        wp.media.frame.on('content:render', function(){ setTimeout(paintAll, 0); });
        wp.media.frame.on('library:selection:add library:selection:remove attach', function(){ setTimeout(paintAll, 0); });
      } catch(e){}
    }
  });
})(jQuery);
JS;
    wp_add_inline_script('media-views', $js, 'after');
});

/** -----------------------------------------------------------------------
 * Helpers
 * --------------------------------------------------------------------- */
function ll706_mop_is_pdf(int $post_id): bool {
    $mime = (string) get_post_mime_type($post_id);
    if ($mime && stripos($mime, 'pdf') !== false) return true;
    $p = get_attached_file($post_id, true);
    return $p && preg_match('/\.pdf$/i', $p);
}

function ll706_mop_ensure_htaccess(): void {
    if (!file_exists(LL706_MOP_DIR)) return;
    $ht = LL706_MOP_DIR . '/.htaccess';
    if (!file_exists($ht)) {
        $rules = <<<HTACC
# LL706 Members-Only PDFs
Options -Indexes

# Apache 2.4+ / LiteSpeed
<IfModule mod_authz_core.c>
  Require all denied
</IfModule>

# Apache 2.2 fallback
<IfModule !mod_authz_core.c>
  Deny from all
</IfModule>
HTACC;
        @file_put_contents($ht, $rules);
    }
}

function ll706_mop_move_file_protection_state(int $attachment_id, bool $protect): void {
    $file = get_attached_file($attachment_id, true);
    if (!$file || !file_exists($file)) return;
    if (!ll706_mop_is_pdf($attachment_id)) return;

    $uploads      = wp_get_upload_dir();
    $uploads_base = wp_normalize_path($uploads['basedir']);
    $basename     = wp_basename($file);
    $protected    = wp_normalize_path(trailingslashit(LL706_MOP_DIR) . $basename);

    if ($protect) {
        if (!get_post_meta($attachment_id, LL706_MOP_META_ORIG, true)) {
            update_post_meta($attachment_id, LL706_MOP_META_ORIG, $basename);
        }
        if (strpos($file, LL706_MOP_DIR) === false) {
            $protected = ll706_mop_unique_path($protected);
            if (@rename($file, $protected)) {
                update_attached_file($attachment_id, $protected);
            }
        }
    } else {
        $subdir     = date('/Y/m/', (int) (filemtime($file) ?: time()));
        $target_dir = wp_normalize_path($uploads_base . $subdir);
        if (!file_exists($target_dir)) wp_mkdir_p($target_dir);
        $target_path = ll706_mop_unique_path(wp_normalize_path($target_dir . wp_basename($file)));
        if (@rename($file, $target_path)) {
            update_attached_file($attachment_id, $target_path);
        }
    }
}

function ll706_mop_unique_path(string $path): string {
    $dir = wp_normalize_path(trailingslashit(dirname($path)));
    $base = pathinfo($path, PATHINFO_FILENAME);
    $ext  = pathinfo($path, PATHINFO_EXTENSION);
    $i = 0;
    $candidate = $path;
    while (file_exists($candidate)) {
        $i++;
        $candidate = $dir . $base . '-' . $i . '.' . $ext;
    }
    return $candidate;
}

function ll706_mop_stream_pdf(string $filepath, string $display_name): void {
    nocache_headers();
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . ll706_mop_suggest_filename($display_name) . '"');
    header('Content-Length: ' . filesize($filepath));
    header('Accept-Ranges: none');

    $last_modified = gmdate('D, d M Y H:i:s', filemtime($filepath)) . ' GMT';
    $etag = '"' . md5($last_modified . '|' . basename($filepath)) . '"';
    header('Last-Modified: ' . $last_modified);
    header('ETag: ' . $etag);

    if (
        (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim($_SERVER['HTTP_IF_NONE_MATCH']) === $etag) ||
        (isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) && trim($_SERVER['HTTP_IF_MODIFIED_SINCE']) === $last_modified)
    ) {
        status_header(304);
        exit;
    }

    status_header(200);
    readfile($filepath);
}

function ll706_mop_suggest_filename(string $name): string {
    $n = trim($name);
    if ($n === '') $n = 'file.pdf';
    if (strtolower(substr($n, -4)) !== '.pdf') $n .= '.pdf';
    $n = str_replace(["\r","\n","\""], ['','',''], $n);
    return $n;
}

function ll706_mop_404(): void {
    status_header(404);
    nocache_headers();
    exit('Not Found');
}